public class Thursday {
    public static void main(String[] args) {
        /*
         * Sorry I was not in class to do this lab due to the fact I had a check up,
         * and I don't know what my AI and UI names are. If note is needed please
         * send an email.
         */
        System.out.println("AI Name");
        System.out.println("UI Name");
        System.out.println("Uziel Rivera-Lopez");
    }
}
