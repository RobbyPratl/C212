import java.util.Scanner;
public class Problem1 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n;
        System.out.print("Enter number of items: ");
        n = sc.nextInt();

        float  sum = 0;
        boolean first = true;
        int max = 0;
        int min = 0;

        for (int i = 0; i < n; i++) {
            int temp;
            if(first){
                System.out.print("Enter "+n+" numbers: ");
                temp = sc.nextInt();
                first = false;
                max= temp;
                min =temp;
            }
            else {
                temp = sc.nextInt();
            }
            sum += (double) temp;
            max = Integer.max(max, temp);
            min = Integer.min(min,temp);
        }
        System.out.println("Mean: "+sum/n);
        System.out.println("Highest: "+max);
        System.out.println("Lowest: "+min);
    }
}
