import java.util.Scanner;
public class Problem3 {
    public static double get_distance(double[] v1, double[] v2) {
        if (v1.length != v2.length)
            return -1;
        double total = 0;
        for (int i = 0; i < v1.length; i++) {
            total += Math.pow(v2[i]-v1[i], 2);
        }
        return Math.sqrt(total);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Dimensions for vectors: ");
        int dims = sc.nextInt();
        double[] vector0 = new double[dims];
        double[] vector1 = new double[dims];
        System.out.println("Input the values for the vectors (" + dims + " * 2 elements): ");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < dims; j++) {
                if (i == 0)
                    vector0[j] = sc.nextDouble();
                else
                    vector1[j] = sc.nextDouble();
            }
        }
        System.out.println("Euclidean distance: " + get_distance(vector0, vector1));
    }
}